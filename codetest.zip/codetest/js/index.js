﻿var items ;
var dragPositionTop;
var dragPositionLeft;
var dropPositionTop;
var dropPositionLeft;
var sourceObject;
var isEditMode = false;

$(function () {
    
    
    $(".dragzones").draggable({
        start: handleDragStart,
        cursor: 'move',
        revert: "invalid"
    });
    $(".dragzones").droppable({
        drop: handleDropEvent,
        tolerance: "touch",
        accept: ":not(#centerBlock)",

    });

    $.getJSON("/json/person.json", function (data) {
        
        items = data;
        setData();
        setMode(false);
    });

    $("#leftbar").draggable();
    $("#leftbar").resizable();
    

});

function handleDragStart(event, ui) {
    dragPositionTop = event.currentTarget.offsetTop;
    dragPositionLeft = event.currentTarget.offsetLeft;
    

}

function handleDropEvent(event, ui) {
    var targetObject = event.currentTarget;
    dropPositionTop = $(this).position().top;
    dropPositionLeft = $(this).position().left;

    $(targetObject).css('top', dragPositionTop);
    $(targetObject).css('left', dragPositionLeft);

    $(sourceObject).css('top', dropPositionTop);
    $(sourceObject).css('left', dropPositionLeft);

    /*if (ui.draggable.element !== undefined) {
        ui.draggable.element.droppable('enable');
    }
    $(this).droppable('disable');
    ui.draggable.position({ of: $(this), my: 'left top', at: 'left top' });
    ui.draggable.draggable('option', 'revert', "invalid");
    ui.draggable.element = $(this);


    $(droppedOn).position({ of: dropped, my: 'left top', at: 'left top' });
    $(droppedOn).draggable('option', 'revert', "invalid");
    $(droppedOn).element = dropped;*/

    /*var dropped = ui.draggable;
    var droppedOn = this;

    if ($(droppedOn).children().length > 0) {
        alert("I need to swap these");
    }

    $(dropped).detach().css({
        top: 0,
        left: 0
    }).prependTo($(droppedOn));*/
}
function setMode(value) {
    isEditMode = value;
    setView();
}
function setView() {
    
    if (isEditMode) {
        $('#spnName').hide();
        $('#spnMail').hide();
        $('#spnPhone').hide();
        $('#spnAge').hide();
        $('#name').show();
        $('#mail').show();
        $('#phone').show();
        $('#age').show();
        $('#btnUpdate').show();
 }
    else {
        $('#spnName').show();
        $('#spnMail').show();
        $('#spnPhone').show();
        $('#spnAge').show();
        $('#name').hide();
        $('#mail').hide();
        $('#phone').hide();
        $('#age').hide();
        $('#btnUpdate').hide();
    }
}
function updateData() {
    items.name = $('#name').val();
    items.email = $('#mail').val();
    items.phone = $('#phone').val();
    items.age = $('#age').val();
    setMode(false);
    setData();
}
function setData() {
    $('#spnName').text(items.name);
    $('#spnMail').text(items.email);
    $('#spnPhone').text(items.phone);
    $('#spnAge').text(items.age);

    $('#spnDepartment').text(items.department);
    $('#spnDepartmentCode').text(items.departmentCoe);

    $('#spnQualification').text(items.qualification);
    $('#spnMode').text(items.mode);

    $('#name').val(items.name);
    $('#mail').val(items.email);
    $('#phone').val(items.phone);
    $('#age').val(items.age);
}